
function chooseClass(characterClass) {
    document.getElementById('game').innerHTML = '<p>Вы выбрали: ' + characterClass + '</p>';
}
